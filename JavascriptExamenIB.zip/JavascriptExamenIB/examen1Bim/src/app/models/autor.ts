import {Libro} from './libro';

export class Autor{
  nombres: string;
  apellidos : string;
  fechaNacimiento : string;
  numeroLibros : number;
  ecuatoriano : boolean;
  libros : Libro[] = [];

}
