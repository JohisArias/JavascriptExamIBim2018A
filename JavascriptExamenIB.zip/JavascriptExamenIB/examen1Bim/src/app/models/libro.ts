export class Libro{
  isbn : number;
  nombreLibro : string;
  numeroPaginas :number;
  edicion : number;
  fechaPublicacion : string;
  nombreEditorial : string;
  autorId : number;
}
