import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  img1='http://www.lavanguardia.com/r/GODO/LV/p3/WebSite/2015/12/24/Recortada/img_crangel_20151224-173349_imagenes_lv_terceros_ilustracion-kFUD-U3010222679448qC-992x558@LaVanguardia-Web.jpg';
  //img2='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRP0sqa0usgCFUgrIFXcgHdp0ic9GXdmcnzI0SpeM9SymtsbFUznw';
  //img3='https://city-confidential.com/sites/default/files/styles/original_big/public/plans/planes-noche-de-los-libros.jpg?itok=hSmM59Vg';
  //img4='https://static.vix.com/es/sites/default/files/styles/large/public/imj/imujer/m/mejores-libros-para-leer-tras-una-ruptura-1_0.jpg?itok=REjqEOif';

  public title = 'Examen Javascript';

}
