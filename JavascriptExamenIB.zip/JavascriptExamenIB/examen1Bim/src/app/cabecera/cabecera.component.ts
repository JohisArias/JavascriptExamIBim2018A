import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {Autor} from '../models/autor';

@Component({
  selector: 'app-cabecera',
  templateUrl: './cabecera.component.html',
  styleUrls: ['./cabecera.component.css']
})
export class CabeceraComponent implements OnInit {

  constructor() { }
@Output() autorCreado: EventEmitter<Autor> = new EventEmitter<Autor>();
  ngOnInit() {
  }

  crearAutor() {
    const autor: Autor = new Autor();
    autor.nombres = ' ';
    autor.apellidos = ' ';
    autor.fechaNacimiento = ' ';
    autor.numeroLibros = 0;
    autor.ecuatoriano = true;
    console.log('[Nuevo Autor]: ', autor);
    this.autorCreado.emit(autor);
  }

}
